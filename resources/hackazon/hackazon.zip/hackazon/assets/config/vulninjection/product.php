<?php
return [
    'fields' => [
        'id' => [
            'sql'
        ],
    ],
    'vulnerabilities' => [
        'csrf' => [
            'enabled' => false
        ]
    ]
];