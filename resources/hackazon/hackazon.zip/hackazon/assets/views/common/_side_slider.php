<div class="slider-wrapper theme-light">
    <div class="ribbon"></div>
    <div id="slider2" class="nivoslider">
        <img src="/images/banner_01-v3.jpg" alt="" data-day-of-week="1"
             title="This is an example of an optional long caption text"/>
        <img src="/images/banner_02-v3.jpg" alt="" data-day-of-week="2" title=""/>
        <img src="/images/banner_03-v3.jpg" alt="" data-day-of-week="5" title=""/>
        <img src="/images/banner_04-v3.jpg" alt="" data-day-of-week="7" title="Another caption"/>
    </div>
</div>
<br>