<p>
You can use our REST service to get actual information about your orders.
</p>
<p>
Orders - <a href="http://webscantest.new/api/order">http://webscantest.new/api/order</a> or <a href="http://webscantest.new/api/order?_format=xml">http://webscantest.new/api/order?_format=xml</a>
</p>
<p>
Address - <a href="http://webscantest.new/api/OrderAddresses">http://webscantest.new/api/orderaddresses</a> or <a href="http://webscantest.new/api/orderaddresses?_format=xml">http://webscantest.new/api/orderaddresses?_format=xml</a>
</p>