<?php
/**
 * Created by IntelliJ IDEA.
 * User: Nikolay Chervyakov 
 * Date: 19.08.2014
 * Time: 17:20
 */


namespace App\Rest;


class Events 
{
    const PRE_PROCESS_REQUEST = 'rest.pre_process_request';
    const PRE_PROCESS_ACTION = 'rest.pre_process_action';
}