<?php
class ApplicationData implements IsSerializable {
	/**
	 * 
	 * @var boolean
	*/
	public $isAutorized;
	
	/**
	 * 
	 * @var user
	*/
	public $user;
	
}
